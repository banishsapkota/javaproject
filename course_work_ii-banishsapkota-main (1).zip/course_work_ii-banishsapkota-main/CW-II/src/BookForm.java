import javax.swing.*;

import java.sql.*;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class BookForm {
	public static void main(String[] args) {
			BookForm bf= new BookForm ();


			
	}

		BookForm(){
				
			JFrame f= new JFrame("Book Interface");
			JLabel title= new JLabel("Enter Book Details...");
			f.setBackground(Color.black);
			f.add(title);
			f.getContentPane().setBackground(Color.ORANGE);
			title.setBounds(280, 6, 500, 200);
			title.setFont(new Font("Felix Titling", Font.BOLD,35));
			
			
			JLabel lId, lName, lPName, lPDate, lStatus, lPrice, setLogo, setLogo1;
			JTextField tfId;
			JTextField tfName;
			JTextField tfPName;
			JTextField tfPDate;
			JTextField tfDate;
			JTextField tfStatus;
			JTextField tfPrice;
			
			JButton btnSave, btnExit;
			
			setLogo= new JLabel(new ImageIcon("C:\\Users\\riyar\\OneDrive\\3rd Sem\\Data Structure and Algorithm\\Courswork2\\image\\bookform2.jpg"));
			f.add(setLogo);
			setLogo.setBounds(0, -100, 250, 400);
			
			setLogo1= new JLabel(new ImageIcon("C:\\Users\\riyar\\OneDrive\\3rd Sem\\Data Structure and Algorithm\\Courswork2\\image\\bookform1.jpg"));
			f.add(setLogo1);
			setLogo1.setBounds(740, 15, 250, 160);
			
			
			JPanel jpan= new JPanel();
	        f.add(jpan);
			jpan.setBounds(150, 185, 690, 400);
			jpan.setBackground(new Color(0,0,0,50));
			jpan.setLayout(null);
			
			
			lId= new JLabel("ID");
			jpan.add(lId);
			lId.setBounds(125, 30, 300, 30);
			tfId= new JTextField(50);
			jpan .add(tfId);
			tfId.setBounds(225, 30, 330, 30);
			
			lName= new JLabel("Name");
			jpan.add(lName);
			lName.setBounds(125, 70, 300, 30);
			tfName= new JTextField(50);
			jpan.add(tfName);
			tfName.setBounds(225, 70, 330, 30);
		
			lPName= new JLabel("Publisher Name");
			jpan.add(lPName);
			lPName.setBounds(125, 110, 300, 30);
			tfPName= new JTextField(30);
			jpan.add(tfPName);
			tfPName.setBounds(225, 110, 330, 30);
			
			lPDate= new JLabel("Published Date");
			jpan.add(lPDate);
			lPDate.setBounds(125, 150, 300, 30);
			tfPDate= new JTextField(30);
			jpan.add(tfPDate);
			tfPDate.setBounds(225, 150, 330, 30);
			
			lStatus= new JLabel("Status");
			jpan.add(lStatus);
			lStatus.setBounds(125, 190, 300, 30);
			String s[]= {"Available", "Out of Stock"};
			JComboBox<String> c1= new JComboBox(s);
			jpan.add(c1);
			c1.setBounds(225, 190, 330, 30);
			
			lPrice= new JLabel("Price");
			jpan.add(lPrice);
			lPrice.setBounds(125, 230, 300, 30);
			tfPrice= new JTextField(30);
			jpan.add(tfPrice);
			tfPrice.setBounds(225, 230, 330, 30);
			
			btnSave = new JButton("Save");
			f.add(btnSave);
			btnSave.setBounds(260, 520, 140, 40);
			btnSave.setFont(new Font("Serif",Font.BOLD, 20));
//			btnSave.setBackground(Color.magenta);
			
			btnExit = new JButton("Exit");
			f.add(btnExit);
			btnExit.setBounds(420, 520, 140, 40);
			btnExit.setFont(new Font("Serif",Font.BOLD, 20));
			

			btnExit.addActionListener(e->{
				int select= JOptionPane.showConfirmDialog(btnExit,"Are you sure?");
				if (select==0) {
					
					f.dispose();
				}
				
			});
			
			btnSave.addActionListener(e->{;
			int ID= Integer.parseInt(tfId.getText());
			String Name= tfName.getText();
			String PublisherName= tfPName.getText();
			String PublishedDate= tfPDate.getText();
			String Status= (String) c1.getSelectedItem();
			int Price= Integer.parseInt(tfPrice.getText());
			
			System.out.println(ID + Name + PublisherName + PublishedDate + Status +Price);
			try {
				DbConnect db= new DbConnect();
				
				String query="Insert into book_table values ("+ID+",'"+Name+"','"+PublisherName+"','"+PublishedDate+"','"+Status+"',"+Price+")";
				System.out.println(query);
				
				int result= db.connection().executeUpdate(query); 				
				if (result>0) {
					JOptionPane.showMessageDialog(btnSave, "Book Added Successfully");
				}else {
					JOptionPane.showMessageDialog(btnSave, "Try Again");
				}
				
				
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	
			});
			
			JButton btnView= new JButton("View Book");
			f.add(btnView);
			btnView.setBounds(580,520, 140,40);
			btnView.setFont(new Font("Serif",Font.BOLD, 20));
			
			btnView.addActionListener(e->{
				new ViewBookDetails();
				f.dispose();
				
			});
			
			f.setLayout(null);
			f.setSize(1000,720);
			f.setVisible(true);
			f.setLocationRelativeTo(null);
			f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
			
		
		}

		
}
